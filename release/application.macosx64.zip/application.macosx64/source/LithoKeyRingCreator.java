import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.opengl.*; 
import controlP5.*; 
import unlekker.data.*; 
import processing.video.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class LithoKeyRingCreator extends PApplet {

/***********************/
/* LithoKeyRingCreator */
/***********************/

/* Bas\u00e9 sur le logiciel image2stl de Joel Belouet */

/* Version sp\u00e9cifique pour CKAB */
/* Joel Belouet http://joel.belouet.free.fr/ */
/* Cyril Chapellier http://tchap.me */

/* Mouse Controls to rotate the shape and zoom */
/* KeyBoar Controls : UP/DOWN/LEFT/RIGHT keys to rotate the shape */
/*                    SPACEBAR to generate the .stl */





ControlP5 controlP5; // controls object
PImage img ; // image object

// Toggles
boolean record;
boolean choooseExportFile = false;
boolean messageExport = false;
boolean capture;
boolean inverse;
boolean flip = false;
boolean square = true;
boolean scaleDown = true;
boolean blur;

// Anchor for keyring
boolean keyring = true;
float L = 10; // half-width of keyring
float e = 2; // width or ring
int def = 16; // number of points on inner circle
float[][] innerPoints;
float[][] outerPoints;

// 3D Camera stuff
float rotY = 45, rotX = 0 ;
float rotYT, rotXT = 30 ;
float zoom = 5;

/// Pixel Ratio
int px_ratio = 4; // 5px ==> 1 mm

// Offset
float offset = 10;
int resX ;
int resY ;

float[][] val ; 
float max_val; float min_val;
boolean preloaded = false ;
float hauteur = 100 ;
String filename = "example.jpg" ; // Must be in "/data"
String export_filename = "example.stl" ; // Must be in "/data"
boolean showGrid = true ;

// Gaussian blur kernel
float v = 1.0f / 9.5f;
float[][] kernel = {{ v, v, v }, 
                    { v, v, v }, 
                    { v, v, v }};
                    
// Faces resolution (in pixels => 2 vertices on an axis equals the width of one pixel)           
int size_image = 202;

// For the render loop
boolean for_STL;
float display_ratio;
float display_pixel_ratio;
float real_offset;
int x_min;
int x_max;
int y_min;
int y_max;
float point1, point2, point3, point4;
int current_color;
float real_e;
float real_L;
float unit_angle;
float angle;
      
// For Video capture      

Capture cam;
String[] cameras;
boolean list_cameras_done = false;
boolean capture_ready;
boolean capture_do;
PImage capturedImg;

public void setup() {
  size(displayWidth, displayHeight, P3D); // Inits OpenGL
  makeControls(); // Creates all controls on screen (defined in controls.pde)
  load_image(); // Loads the default image
}

public void draw() {

  background(0);

  // rotation ---
  if ( rotXT != rotX ) {
    rotX += ( rotXT - rotX ) / 5 ;
    if ( abs(rotX - rotXT) < 1 ) rotX = rotXT ;
  }
  if ( rotYT != rotY ) {
    rotY += ( rotYT - rotY ) / 5 ;
    if ( abs(rotY - rotYT) < 1 ) rotY = rotYT ;
  }
  //------------

  if ( preloaded ) {

    if (choooseExportFile == true) {
      selectOutput("O\u00f9 voulez-vous exporter le fichier STL ?", "exportFileChosen");
      choooseExportFile = false;
    }
    
    if (record == true) { // Ready to Record ? ...

      rec();
    }
    
    if (capture == true) { // Display webcam
      capture(); 
    }
    
    if (capture_ready == true) { // Take current camera snapshot
      take_snapshot();
    }
  
    // Drawing the shape extruded from the image according to the brightness values
    if (!record && !capture && !capture_ready) {
      
      if (messageExport == true && choooseExportFile == false) { message("Exporting in progress"); }
      pushMatrix();
      translate(5*width/9, height/2);
      rotateY(radians(rotY));
      rotateX(radians(rotX));
      rotateZ(radians(180));
      renderLoop();
      
      view();
      popMatrix();
  
    }
    
  }
  
  labels();
  credits();
}

public void view() {

  if ( showGrid ) { // drawing the grid
    stroke(150,125);
    line (-200*zoom, 0, 200*zoom, 0 );
    line (0, -200*zoom, 0, 200*zoom );
    stroke(255,125);
    for ( int i=-PApplet.parseInt(6*10*zoom); i<=PApplet.parseInt(6*10*zoom) ; i+=PApplet.parseInt(10*zoom) ) {
      line (i, -50*zoom, i, 50*zoom );
    }
    for ( int i=-PApplet.parseInt(6*10*zoom); i<=PApplet.parseInt(6*10*zoom) ; i+=PApplet.parseInt(10*zoom) ) {
      line (-50*zoom, i, 50*zoom, i );
    }
    stroke(100,125);
    pushMatrix();
    rotateX(radians(90));
    line (0, 0, 0, 100*zoom );
    for ( int i=0; i<=6*10*zoom ; i+=10*zoom ) {
      line (-5*zoom, i, 5*zoom, i );
    }
    popMatrix();
  }
}


public void checkPixels() {

  //Blurs stuff first
  if (blur) {
 
    // Create an opaque image of the same size as the original
    PImage edgeImg = createImage(img.width, img.height, RGB);
  
    edgeImg.loadPixels();
    // Loop through every pixel in the image
    for (int y = 1; y < img.height-1; y++) {   // Skip top and bottom edges
      for (int x = 1; x < img.width-1; x++) {  // Skip left and right edges
        float sum = 0; // Kernel sum for this pixel
        for (int ky = -1; ky <= 1; ky++) {
          for (int kx = -1; kx <= 1; kx++) {
            // Calculate the adjacent pixel for this kernel point
            int pos = (y + ky)*img.width + (x + kx);
            // Image is grayscale, red/green/blue are identical
            float val = red(img.pixels[pos]);
            // Multiply adjacent pixels based on the kernel values
            sum += kernel[ky+1][kx+1] * val;
          }
        }
        // For this pixel in the new image, set the gray value
        // based on the sum from the kernel
        edgeImg.pixels[y*img.width + x] = color(sum);
      }
    }
    // State that there are changes to edgeImg.pixels[]
    edgeImg.updatePixels();
    img = edgeImg;
    
  }
        
  // Generates the border that extends the surface to Z=0 for watertightness
  int border_color = color(255);
  if ( !inverse ) {
    border_color = color(255); //  (255 = top when not inverse)
  } else {
    border_color = color(0);
  }
  
  // We put a 1px "black" border around the image (black or white depending on way of extrusion)
  img.loadPixels();
  int total = img.pixels.length;

  for (int i = 0; i < total; i++) {
    if ( i%img.width == 0 ) { img.pixels[i] = border_color; } // Left border
    if ( i<img.width ) { img.pixels[i] = border_color; } // Top border
    if ( i>total-img.width) { img.pixels[i] = border_color; } // Bottom border 
    if ( i%img.width == 0 && i>0 ) { img.pixels[i-1] = border_color; } // Right border
  }
  
  // Let's update the image to reflect the changes
  img.updatePixels();
  
  // Then Checks the brightness value of each pixel in the image
  // 0 < val < 1*hauteur
  max_val = 0; min_val = 0;
  for (int x =0; x<resX; x++) {
    for (int y =0; y<resY; y++) {      
      if ( !inverse ) {
        val[x][y] = (-brightness(img.get((flip)?x:(resX-x), y))+255)/255*hauteur;
      } else { 
        val[x][y] = brightness(img.get((flip)?x:(resX-x), y))/255*hauteur;
      }
      max_val = max(max_val, abs(val[x][y]));
      min_val = min(min_val, abs(val[x][y]));
    }
  }

}


// Records the data inside a STL buffer in unlekker
public void exportFileChosen(File selection) {
 
 if (selection != null) {
    
    export_filename = selection.getAbsolutePath();
    int l = export_filename.length();
    String extension = ".STL";
    if (export_filename.substring(l-4,l).toUpperCase().equals(extension) == false) {
      export_filename = export_filename + ".STL";
    }
    
 }
 
 record = true;

}

public void rec() {

  beginRaw("unlekker.data.STL", export_filename);
    print("begin .. ");
    renderLoop();
  endRaw();
  println(" .. end");
  record = false;
  messageExport = false;
  
}

public void capture() {
  if (!list_cameras_done)   {
    cameras = Capture.list();
    list_cameras_done = true;
    if (cameras.length == 0) {
      message("No cameras available for capture.");
      capture = false;
    } else {
      println("Available cameras:");
      for (int i = 0; i < cameras.length; i++) {
        println(i + " : " + cameras[i]);
      }
    }
  }
  cam = new Capture(this);
  cam.start(); 
  capture = false; 
  capture_do = false; 
  capture_ready = true;
  capture_button();
  println( "c : " + capture + " c_do : " + capture_do + " cread : " + capture_ready );
  
}

public void take_snapshot(){
  if (cam.available() == true) {
      cam.read();
    }
    
    loadPixels();
    cam.loadPixels(); 
    // Wait for the size of the camera
    if (cam.width > 0 && cam.height > 0) {
      if (cam.width > 1280) {
        capturedImg = createImage(cam.width, cam.height, RGB);
        capturedImg.copy(cam,0,0,cam.width, cam.height, 0,0,cam.width, cam.height);
        capturedImg.resize(720, 0);
        image(capturedImg, 5*width/9, height/2-50, capturedImg.width, capturedImg.height);
      } else {
        image(cam, 5*width/9, height/2-50);
      }
    }
    
    if (capture_do == true && cam.width > 0 && cam.height > 0) {
      // Take image
      capturedImg = createImage(cam.width, cam.height, RGB);
      capturedImg.copy(cam,0,0,cam.width, cam.height, 0,0,cam.width, cam.height);
      capturedImg.resize(720, 0);
      println("Capturing at w : " + capturedImg.width + " & h : " + capturedImg.height);
      capturedImg.updatePixels();
      cam.stop();
      cam.stop();
      capture_ready = false; 
      capture_do = false; 
      capture = false;
      capture_button();
      load_image();
      checkPixels();
    }
}

// The main render loop for screens and STL
public void renderLoop() {
  
  for_STL = (record);
  
  display_ratio = zoom;
  if (for_STL) { display_ratio = 1; }
  display_pixel_ratio = display_ratio/px_ratio;
  
  real_offset = offset*display_ratio;
  x_min = floor(resX/2);
  x_max = ceil(resX/2);
  y_min = floor(resY/2);
  y_max = ceil(resY/2);

  rotateZ(radians(180));
  colorMode(HSB, 255);
  noFill();
  
  for (int x =-x_min; x<x_max-1; x++) {
    for (int y =-y_min; y<y_max-1; y++) {

      current_color = PApplet.parseInt((val[x+x_min][y+y_min]*230)/max_val);
    
      beginShape();      
      stroke(current_color, 255, 255);
      if (for_STL) {
        fill(current_color, 255, 255);
      }
      
      point1 = (val[x+x_min][y+y_min]-min_val)*display_ratio + real_offset;
      point2 = (val[x+x_min+1][y+y_min]-min_val)*display_ratio + real_offset;
      point3 = (val[x+x_min+1][y+1+y_min]-min_val)*display_ratio + real_offset;
      point4 = (val[x+x_min][y+1+y_min]-min_val)*display_ratio + real_offset;
      
      // Try to triangulate 
      // CASE 0 : all points at the same height : QUAD
      if ( point1 == point4 && point1 == point2 && point1 == point3 ) {
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, point1);
        vertex(x*display_pixel_ratio, (y+1)*display_pixel_ratio, point4);
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, point3);
        vertex((x+1)*display_pixel_ratio, y*display_pixel_ratio, point2);
      //----- END OF CASE 0
      // CASE 1&2 : three points aligned
      } else if ( (point1 == point3 && point1 == point2) || (point1 == point3 && point1 == point4) ) {
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, point1);
        vertex(x*display_pixel_ratio, (y+1)*display_pixel_ratio, point4);
        vertex((x+1)*display_pixel_ratio, y*display_pixel_ratio, point2);
        endShape(CLOSE);
        beginShape();
        vertex((x+1)*display_pixel_ratio, y*display_pixel_ratio, point2);
        vertex(x*display_pixel_ratio, (y+1)*display_pixel_ratio, point4); 
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, point3);
      } else if ( (point1 == point4 && point1 == point2) || (point2 == point3 && point2 == point4) ) {
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, point1);
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, point3);
        vertex((x+1)*display_pixel_ratio, y*display_pixel_ratio, point2);
        endShape(CLOSE);
        beginShape();
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, point1);
        vertex(x*display_pixel_ratio, (y+1)*display_pixel_ratio, point4); 
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, point3);
      //----- END OF CASE 1&2
      // CASE 3 : two by two
      } else if (point1 == point3 && point2 == point4 && point2 > point3 ) { // 2 triangles
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, point1);
        vertex(x*display_pixel_ratio, (y+1)*display_pixel_ratio, point4);
        vertex((x+1)*display_pixel_ratio, y*display_pixel_ratio, point2);
        endShape(CLOSE);
        beginShape();
        vertex((x+1)*display_pixel_ratio, y*display_pixel_ratio, point2);
        vertex(x*display_pixel_ratio, (y+1)*display_pixel_ratio, point4); 
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, point3);
      } else if (point1 == point3 && point2 == point4 && point2 < point3 ) { // 2 triangles
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, point1);
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, point3);
        vertex((x+1)*display_pixel_ratio, y*display_pixel_ratio, point2);
        endShape(CLOSE);
        beginShape();
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, point1);
        vertex(x*display_pixel_ratio, (y+1)*display_pixel_ratio, point4); 
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, point3);
      // ----- END OF CASE 3
      } else { // Well, let's choose a side
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, point1);
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, point3);
        vertex((x+1)*display_pixel_ratio, y*display_pixel_ratio, point2);
        endShape(CLOSE);
        beginShape();
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, point1);
        vertex(x*display_pixel_ratio, (y+1)*display_pixel_ratio, point4); 
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, point3);
      }
      
      endShape(CLOSE);
      
    }
  }
  
  stroke(125, 125, 125);
  fill(125, 100);
  
  // Keyring
  if (keyring) {
  
    def = PApplet.parseInt(L*3);
    if (e >= L) { e = L - 2; }
    if (L > resX/(2*px_ratio)) { L = PApplet.parseInt(resX/(2*px_ratio)); }
    real_e = e*px_ratio;
    real_L = L*px_ratio;

    innerPoints = new float[def][2];
    outerPoints = new float[def][2];
    unit_angle = PI/(def-1);
    
    // Create inner & outer points
    for(int i=0; i<def; i++) {
      angle = i*unit_angle;
      innerPoints[i][0] = (real_L - real_e)*cos(angle)*display_pixel_ratio;
      innerPoints[i][1] = (-y_min - (real_L - real_e)*sin(angle))*display_pixel_ratio;
      outerPoints[i][0] = real_L*cos(angle)*display_pixel_ratio;
      outerPoints[i][1] = (-y_min - real_L*sin(angle))*display_pixel_ratio;
    }

    // Now create triangles
    for (int j=0; j<def-1; j++) {
        // Floor
        if (j==0 && for_STL) {
          for(int k=0; k<real_e; k++) {
            beginShape();
            vertex((real_L - real_e + k)*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
            vertex(outerPoints[j+1][0], outerPoints[j+1][1], 0);
            vertex((real_L - real_e + k+1)*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
            endShape(CLOSE);
          }
        } else {
          beginShape();
          vertex(innerPoints[j][0], innerPoints[j][1], 0);
          vertex(outerPoints[j+1][0], outerPoints[j+1][1], 0);
          vertex(outerPoints[j][0], outerPoints[j][1], 0);
          endShape(CLOSE);
        }
        if (j==def-2 && for_STL) {
          for(int k=0; k<real_e; k++) {
            beginShape();
            vertex(innerPoints[j][0], innerPoints[j][1], 0);
            vertex((-(real_L - real_e) - k)*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
            vertex((-(real_L - real_e) - k-1)*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
            endShape(CLOSE);
          }
        } else {
          beginShape();
          vertex(innerPoints[j][0], innerPoints[j][1], 0);
          vertex(innerPoints[j+1][0], innerPoints[j+1][1], 0);
          vertex(outerPoints[j+1][0], outerPoints[j+1][1], 0);
          endShape(CLOSE);
        }
        //Ceil
        if (j==0 && for_STL) {
          for(int k=0; k<real_e; k++) {
            beginShape();
            vertex((real_L - real_e + k)*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
            vertex((real_L - real_e + k+1)*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
            vertex(outerPoints[j+1][0], outerPoints[j+1][1], real_offset);
            endShape(CLOSE);
          }
        } else {
          beginShape();
          vertex(innerPoints[j][0], innerPoints[j][1], real_offset);
          vertex(outerPoints[j][0], outerPoints[j][1], real_offset);
          vertex(outerPoints[j+1][0], outerPoints[j+1][1], real_offset);
          endShape(CLOSE);
        }
        if (j==def-2 && for_STL) {
          for(int k=0; k<real_e; k++) {
            beginShape();
            vertex(innerPoints[j][0], innerPoints[j][1], real_offset);
            vertex((-(real_L - real_e) - k-1)*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
            vertex((-(real_L - real_e) - k)*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
            endShape(CLOSE);
          }
        } else {
          beginShape();
          vertex(innerPoints[j][0], innerPoints[j][1], real_offset);
          vertex(outerPoints[j+1][0], outerPoints[j+1][1], real_offset);
          vertex(innerPoints[j+1][0], innerPoints[j+1][1], real_offset);
          endShape(CLOSE);
        }
        // Outer shell
        beginShape();
        vertex(outerPoints[j][0], outerPoints[j][1], real_offset);
        vertex(outerPoints[j][0], outerPoints[j][1], 0);
        vertex(outerPoints[j+1][0], outerPoints[j+1][1], 0);
        endShape(CLOSE);
        beginShape();
        vertex(outerPoints[j][0], outerPoints[j][1], real_offset);
        vertex(outerPoints[j+1][0], outerPoints[j+1][1], 0);
        vertex(outerPoints[j+1][0], outerPoints[j+1][1], real_offset);
        endShape(CLOSE);
        // Inner shell
         beginShape();
        vertex(innerPoints[j][0], innerPoints[j][1], real_offset);
        vertex(innerPoints[j+1][0], innerPoints[j+1][1], 0);
        vertex(innerPoints[j][0], innerPoints[j][1], 0);
        endShape(CLOSE);
        beginShape();
        vertex(innerPoints[j][0], innerPoints[j][1], real_offset);
        vertex(innerPoints[j+1][0], innerPoints[j+1][1], real_offset);
        vertex(innerPoints[j+1][0], innerPoints[j+1][1], 0);
        endShape(CLOSE);
    }
  
}
  
  
  // Bottom line and right line cannot be determined since pixels = points
  // so for the closing shape we need to strip one line right and one line at the bottom
  // hence x_max-1 and y_max -1
  
  // Close shape
  
  if (for_STL) {
    // Fond correctement triangul\u00e9
    for (int x =-x_min; x<x_max-1; x++) {
      for (int y =-y_min; y<y_max-1; y++) {
        beginShape();
        vertex(x*display_pixel_ratio, y*display_pixel_ratio, 0);
        vertex((x+1)*display_pixel_ratio, y*display_pixel_ratio, 0);
        vertex((x+1)*display_pixel_ratio, (y+1)*display_pixel_ratio, 0);
        vertex(x*display_pixel_ratio, (y+1)*display_pixel_ratio, 0);
        endShape(CLOSE);
      }
    }
      
    // LEFT
    for (int y =-y_min; y<y_max-1; y++) {
      beginShape();
      vertex(-x_min*display_pixel_ratio, y*display_pixel_ratio, real_offset);
      vertex(-x_min*display_pixel_ratio, y*display_pixel_ratio, 0 );
      vertex(-x_min*display_pixel_ratio, (y+1)*display_pixel_ratio, 0);
      vertex(-x_min*display_pixel_ratio, (y+1)*display_pixel_ratio, real_offset );
      endShape(CLOSE);
    }
    
    // BOTTOM
    for (int x =-x_min; x<x_max-1; x++) {
      beginShape(); // BOTTOM
      vertex(x*display_pixel_ratio, (y_max-1)*display_pixel_ratio, real_offset);
      vertex(x*display_pixel_ratio, (y_max-1)*display_pixel_ratio, 0 );
      vertex((x+1)*display_pixel_ratio, (y_max-1)*display_pixel_ratio, 0);
      vertex((x+1)*display_pixel_ratio, (y_max-1)*display_pixel_ratio, real_offset);
      endShape(CLOSE);
    }
     
    // RIGHT
    for (int y =-y_min; y<y_max-1; y++) {
      beginShape();
      vertex((x_max-1)*display_pixel_ratio, y*display_pixel_ratio, real_offset);
      vertex((x_max-1)*display_pixel_ratio, (y+1)*display_pixel_ratio, real_offset );
      vertex((x_max-1)*display_pixel_ratio, (y+1)*display_pixel_ratio, 0);
      vertex((x_max-1)*display_pixel_ratio, y*display_pixel_ratio, 0 );
      endShape(CLOSE);
    }
    
    // TOP
    for (int x =-x_min; x<x_max-1; x++) {
      // We need to strip down the triangles above the keyring if any
      if (!keyring || (( x>=0 && (x >= L*px_ratio || x < (L-e)*px_ratio)) || (x<=0 && (x < -L*px_ratio || x >= -(L-e)*px_ratio))) ) {
        beginShape(); // BOTTOM
        vertex(x*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
        vertex((x+1)*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
        vertex((x+1)*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
        vertex(x*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
        endShape(CLOSE);
      }
    }
  
  } else {
    // Fond simple pour la visualisation
    beginShape();
    vertex(-x_min*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
    vertex(-x_min*display_pixel_ratio, (y_max-1)*display_pixel_ratio, 0);
    vertex((x_max-1)*display_pixel_ratio, (y_max-1)*display_pixel_ratio, 0);
    vertex((x_max-1)*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
    endShape(CLOSE);
      
    // LEFT
    beginShape();
    vertex(-x_min*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
    vertex(-x_min*display_pixel_ratio, (y_max-1)*display_pixel_ratio, real_offset );
    vertex(-x_min*display_pixel_ratio, (y_max-1)*display_pixel_ratio, 0);
    vertex(-x_min*display_pixel_ratio, -y_min*display_pixel_ratio, 0 );
    endShape(CLOSE);
 
    // BOTTOM
    beginShape(); // BOTTOM
    vertex(-x_min*display_pixel_ratio, (y_max-1)*display_pixel_ratio, real_offset);
    vertex(-x_min*display_pixel_ratio, (y_max-1)*display_pixel_ratio, 0 );
    vertex((x_max-1)*display_pixel_ratio, (y_max-1)*display_pixel_ratio, 0);
    vertex((x_max-1)*display_pixel_ratio, (y_max-1)*display_pixel_ratio, real_offset);
    endShape(CLOSE);
  
    // RIGHT
    beginShape();
    vertex((x_max-1)*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
    vertex((x_max-1)*display_pixel_ratio, (y_max-1)*display_pixel_ratio, real_offset );
    vertex((x_max-1)*display_pixel_ratio, (y_max-1)*display_pixel_ratio, 0);
    vertex((x_max-1)*display_pixel_ratio, -y_min*display_pixel_ratio, 0 );
    endShape(CLOSE);
    
    // TOP
    beginShape(); // BOTTOM
    vertex(-x_min*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
    vertex((x_max-1)*display_pixel_ratio, -y_min*display_pixel_ratio, real_offset);
    vertex((x_max-1)*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
    vertex(-x_min*display_pixel_ratio, -y_min*display_pixel_ratio, 0);
    endShape(CLOSE);

  }
  
}

/***********************/
/* LithoKeyRingCreator */
/***********************/

/* Bas\u00e9 sur le logiciel image2stl de Joel Belouet */

/* Version sp\u00e9cifique pour CKAB */
/* Joel Belouet http://joel.belouet.free.fr/ */
/* Cyril Chapellier http://tchap.me */



/* Creates the GUI */
Button cap;

public void makeControls() {

  controlP5 = new ControlP5(this);
  
  controlP5.addButton("Choisir", 0.0f, 25, 145, 90, 30);
  controlP5.addButton("Webcam", 0.0f, 125, 145, 90, 30);
  controlP5.addToggle("ratio", true, 25, 185, 15, 15);
  controlP5.addToggle("lisser", false, 55, 185, 15, 15);
  controlP5.addToggle("reduire", true, 85, 185, 15, 15);
  controlP5.addToggle("retourner", false, 125, 185, 15, 15);
  
  controlP5.addSlider("px_ratio", 4, 10, 4, 25, 270, 150, 15);
  Slider s0 = (Slider)controlP5.controller("px_ratio");
  s0.setLabel("pixel / mm");
  s0.setNumberOfTickMarks(11);
  
  controlP5.addSlider("hauteur", 0, 60, 15, 25, 325, 150, 15);
  Slider s1 = (Slider)controlP5.controller("hauteur");
  s1.setLabel("hauteur (1/10mm )");
  s1.setNumberOfTickMarks(61);
  
  controlP5.addSlider("offset", 1, 10, 1, 25, 355, 150, 15);
  Slider s2 = (Slider)controlP5.controller("offset");
  s2.setLabel("offset (1/10mm )");
  s2.setNumberOfTickMarks(10);

  controlP5.addToggle("inverser", false, 25, 385, 15, 15);
  
  controlP5.addToggle("activer", true, 25, 530, 15, 15);
  
  controlP5.addSlider("largeur", 5, 50, 20, 25, 470, 150, 15);
  Slider s4 = (Slider)controlP5.controller("largeur");
  s4.setLabel("largeur ( mm )");
  s4.setNumberOfTickMarks(16);
  
  controlP5.addSlider("epaisseur", 10, 30, 20, 25, 500, 150, 15);
  Slider s5 = (Slider)controlP5.controller("epaisseur");
  s5.setLabel("epaisseur ( 1/10 mm )");
  s5.setNumberOfTickMarks(21);
  
  controlP5.addToggle("grille", true, 25, 615, 15, 15);

  controlP5.addButton("Exporter", 0.0f, 25, 730, 120, 30);

  cap = controlP5.addButton("Capturer", 0.0f, 5*width/9-25, 60, 50, 40);
  cap.setColorBackground(color(255, 128, 0, 128));
  cap.hide();
}

public void labels() {
  fill(255);
  stroke(255);
  
  
  text ( "Fichier image :", 25, 135 );
  line( 18, 125, 18, 215);

  text ( "Ratio pixel par mm :", 25, 255 );
  text ( "D\u00e9formation :", 25, 315 );
  line ( 18, 245, 18, 415 ); 

  text ( "Anse :", 25, 460 );
  line ( 18, 450, 18, 560 ); 

  text ( "Vue :", 25, 605 );
  line ( 18, 595, 18, 645 );

  text ( "G\u00e9n\u00e9rer le .STL :", 25, 720 );
  line ( 18, 710, 18, 760 );
  
}

public void credits() {
  fill(255);
  text ( "image2stl vCKAB", 5.5f*width/6, height-60 );
}

public void capture_button(){
  if (capture_ready) {
    cap.show();
  } else { 
    cap.hide();
  }
}


public void message(String s) {
  fill(0, 255, 255);
  noStroke();
  rect(18, 18, 2*width/10, 90);
  fill(255);
  stroke(0);
  text ( "Please wait ...",140, 60);
  text ( s, 120, 72);
}


public void load_image() {

    if (capturedImg == null) {
      img = loadImage(filename);
    } else {
      capturedImg.loadPixels();
      img = createImage(capturedImg.width, capturedImg.height, RGB);
      img.copy(capturedImg,0,0, capturedImg.width, capturedImg.height, 0, 0, capturedImg.width, capturedImg.height);
      img.updatePixels();
    }
    if ( img == null ) {
      preloaded = false;
    } else {
      preloaded = true;
    }
    
    println("Original image : " + img.width + "x" +img.height);
    if ( preloaded ) {
      imageMode(CENTER);
      
      // Foolproof image size for large images
      if (img.width > 800 || img.height > 800) {
        if ( img.width > img.height ) {
          img.resize(800, 0);
        } else {
          img.resize(0, 800);
        }
      }
      
      // Make square
      if (square == true) {
        int min_size = min(img.width, img.height);
        PImage squareImg = createImage(min_size, min_size, RGB);
        squareImg.copy(img, (img.width-min_size)/2, (img.height-min_size)/2, min_size, min_size, 0, 0, min_size, min_size);
        
        resX = min_size;
        resY = min_size;
        val = new float[resX][resY];
        println(" >> Image squared to '" + min_size + "px'");

        if (scaleDown == true) {
          squareImg.resize(size_image, 0);
          println(" >> Image resized to '" + size_image + "px'");
        }
        img = squareImg;
        img.updatePixels();
      } else if (scaleDown == true) {
        println(" >> Image resized to '" + size_image + "px'");
        if ( img.width > img.height ) {
          img.resize(size_image, 0);
        } else {
          img.resize(0, size_image);
        }    
      }
      
      img.loadPixels();    
      resX = img.width;
      resY = img.height;
      println("New size : " + img.width + "x" +img.height);
      val = new float[resX][resY];

      checkPixels();
    }
}

/* Interface Buttons to toggle values */
public void inverser(boolean theFlag) {
  inverse = theFlag;
  checkPixels();
}

public void lisser(boolean theFlag) {
  blur = theFlag;
  load_image();
  checkPixels();
}

public void reduire(boolean theFlag) {
  scaleDown = theFlag;
  load_image();
  checkPixels();
}

public void grille(boolean theFlag) {
  showGrid = theFlag;
}

public void activer(boolean theFlag) {
  keyring = theFlag;
}

public void retourner(boolean theFlag) {
  flip = theFlag;
  load_image();
  checkPixels();
}

public void ratio(boolean theFlag) {
  square = theFlag;
  load_image();
  checkPixels();
}

/* Sliders */
public void offset(float off) {
  offset = off/10;
  // checkPixels();
  // println("INFO : Setting Offset to : " + offset);
}

// Extrusion height
public void hauteur(float haut) {
  hauteur = haut/10;
  checkPixels();
  // println("INFO : Setting Height to " + hauteur + " mm");
}

// Keyring width
public void largeur(int larg) {
  L = larg/2;
  // checkPixels();
  // println("INFO : Setting Height to " + hauteur + " mm");
}

// Keyring width
public void epaisseur(int ep) {
  e = PApplet.parseFloat(ep)/10;
  // checkPixels();
  // println("INFO : Setting Height to " + hauteur + " mm");
}

// PX Ratio
public void px_ratio(int ratio) {
  px_ratio = ratio;
  checkPixels();
  // println("INFO : Setting PX Ratio to : "+ echelle);
}

/***********************/
/* LithoKeyRingCreator */
/***********************/

/* Bas\u00e9 sur le logiciel image2stl de Joel Belouet */

/* Version sp\u00e9cifique pour CKAB */
/* Joel Belouet http://joel.belouet.free.fr/ */
/* Cyril Chapellier http://tchap.me */


/* Zooming with the wheel */
public void mouseWheel(MouseEvent event) {
  println(event.getCount());
  zoom = min(max(5.0f,zoom - PApplet.parseFloat(event.getCount())/5.0f),20.0f);
  println("zoom " + zoom);
  //checkPixels();
  //s3.setValue(zoom);
  // println("INFO : Setting Zoom to : " + meshSize);
}

/* Rotating (left-click) */
public void mouseDragged() { 
  
  if ( mouseX > 200 ) {
    
    if ( pmouseX < mouseX ) {
      rotYT += mouseX - pmouseX;
    } else {
      rotYT -= pmouseX - mouseX;
    }

    if ( pmouseY < mouseY ) {
      rotXT -= mouseY - pmouseY;
    } else {
      rotXT += pmouseY - mouseY;
    }
  }
  
}


/* KeyBoar Controls : UP/DOWN/LEFT/RIGHT keys to rotate the shape */
/*                    SPACEBAR to generate the .stl */
public void keyPressed() {

  switch(keyCode) {
  case LEFT: 
    rotYT -= 15 ;
    break;
  case RIGHT: 
    rotYT += 15 ;
    break;
  case UP: 
    rotXT += 15 ;
    break;
  case DOWN: 
    rotXT -= 15 ;
    break;
  case BACKSPACE: // You can use BackSpace to generate the .stl  
    record = true;
    break;
  default:           
    break;
  }
}


/* When clicking on "choose" */
public void controlEvent(ControlEvent theEvent) {
  if (theEvent.getController().getName() == "Choisir") {
      selectInput("Choisir une image (jpg, jpeg ou png) : ", "fileSelected");
  } else if (theEvent.getController().getName() == "Exporter") {
    choooseExportFile = true;
    messageExport = true;
  } else if (theEvent.getController().getName() == "Webcam") {
    message("Initializing video");
    capture = true;
  } else if (theEvent.getController().getName() == "Capturer") {
    capture_do = true;
  }
}

public void fileSelected(File selection) {
  if (selection != null) {
    capturedImg = null;
    filename = selection.getAbsolutePath();
    println("User selected " + filename);
    load_image();
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "LithoKeyRingCreator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
